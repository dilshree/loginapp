<?php
	// =====================================================================================
	// FLATPACK Email Settings
	// =====================================================================================
	// Replace with your email and custom subject

		$to_Email       = "pixfort.com@gmail.com"; //Replace with recipient email address
		$subject        = 'An email from FLATPACK contact form'; //Subject line for emails

	// =====================================================================================
	// All rights reserved Copyright © 2015 FLATPACK by PixFort
	// http://themeforest.net/user/PixFort
	// =====================================================================================
?>